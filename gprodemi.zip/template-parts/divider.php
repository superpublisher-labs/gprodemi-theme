<?php
if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<div class="w-full h-1.5 container mx-auto bg-gradient-to-r rounded-full from-[var(--color-divider)]/50 via-[var(--color-divider)]/30 to-[var(--color-divider)]/5"></div>